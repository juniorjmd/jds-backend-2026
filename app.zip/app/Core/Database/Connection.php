<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace App\Core\Database;

/**
 * Description of Connection
 *
 * @author junio
 */
class Connection {
    //put your code here
}
