<?php
declare(strict_types=1);

namespace App\Bootstrap;

use App\Core\Http\Request;

final class Routes
{
    /** @return array<string, callable> */
    public static function map(): array
    {
        return [
            'PING' => function (Request $req) {
                return [
                    'pong' => true,
                    'action' => $req->action(),
                    'time' => date('c'),
                ];
            },
        ];
    }
}