<?php
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Routing\Router;
use App\Bootstrap\Routes;
//use App\Test\Test;

//echo Test::hola();
try {
    $request = Request::fromGlobals();

    // CORS + preflight (mínimo)
    if ($request->method() === 'OPTIONS') {
        Response::noContent();
        return;
    }

    $router = new Router(Routes::map());
    $result = $router->dispatch($request);

    Response::ok($result);

} catch (Throwable $e) {
    // En dev podrías devolver detalle, en prod solo mensaje genérico
    Response::fail('INTERNAL_ERROR', 'Error interno del servidor', 500, [
        'exception' => get_class($e),
        'message' => $e->getMessage(),
    ]);
}